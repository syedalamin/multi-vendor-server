-- DropIndex
DROP INDEX "city_name_districtId_key";
