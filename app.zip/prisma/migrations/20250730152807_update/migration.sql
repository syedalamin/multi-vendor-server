-- AlterTable
ALTER TABLE "cart" ALTER COLUMN "discountAmount" DROP DEFAULT,
ALTER COLUMN "discountPercent" DROP DEFAULT,
ALTER COLUMN "discountPrice" DROP DEFAULT;
