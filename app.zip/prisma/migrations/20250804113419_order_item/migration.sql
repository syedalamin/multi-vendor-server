-- AlterTable
ALTER TABLE "orderItem" ADD COLUMN     "discountPrice" DECIMAL(65,30) NOT NULL DEFAULT 0;
