/*
  Warnings:

  - You are about to drop the column `image` on the `orderItem` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "orderItem" DROP COLUMN "image";
