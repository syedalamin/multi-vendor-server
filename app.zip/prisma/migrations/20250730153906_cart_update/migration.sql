-- AlterTable
ALTER TABLE "cart" ALTER COLUMN "discountAmount" SET DEFAULT 0,
ALTER COLUMN "discountPercent" SET DEFAULT 0,
ALTER COLUMN "discountPrice" SET DEFAULT 0;
