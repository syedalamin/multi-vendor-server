-- AlterTable
ALTER TABLE "Product" ALTER COLUMN "stock" DROP DEFAULT;
