-- DropIndex
DROP INDEX "district_name_key";
