-- AlterTable
ALTER TABLE "orderItem" ADD COLUMN     "image" TEXT NOT NULL DEFAULT 'https://res.cloudinary.com/dluxn37lw/image/upload/v1755285486/Green-Apple.webp.webp';
