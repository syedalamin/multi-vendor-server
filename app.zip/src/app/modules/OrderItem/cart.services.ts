const createDataIntoDB = () => {};
const getAllDataFromDB = () => {};
const getByIdFromDB = () => {};
const updateByIdIntoDB = () => {};
const deleteByIdFromDB = () => {};

export const CartServices = {
  createDataIntoDB,
  getAllDataFromDB,
  getByIdFromDB,
  updateByIdIntoDB,
  deleteByIdFromDB,
};
