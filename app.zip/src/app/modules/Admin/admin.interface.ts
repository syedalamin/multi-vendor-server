export type IAdminFilterRequest = {
  firstName?: string | undefined;
  lastName?: string | undefined;
  email?: string | undefined;
  searchTerm?: string | undefined;
  contactNumber?: string | undefined;
};