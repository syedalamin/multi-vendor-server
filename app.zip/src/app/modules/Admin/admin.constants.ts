export const adminFilterableFields = [
  "firstName",
  "lastName",
  "email",
  "searchTerm",
  "contactNumber",
];

export const adminSearchAbleFields = ["firstName", "lastName", "email" ];
