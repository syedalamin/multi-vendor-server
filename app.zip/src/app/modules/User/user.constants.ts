export const userFilterableFields = ["email", "searchTerm"];

export const userSearchAbleFields = ["email"];
