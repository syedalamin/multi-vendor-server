export const productFilterAbleField = ["searchTerm", "name"]
export const allowedProductSortAbleField = ["price", "stock", "discount", "averageRating"]