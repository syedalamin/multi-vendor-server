import status from "http-status";
import { paginationFilterableField } from "../../../utils/pagination/pagination";
import pick from "../../../utils/search/pick";
import catchAsync from "../../../utils/share/catchAsync";
import sendResponse from "../../../utils/share/sendResponse";
import { productFilterAbleField } from "./product.constant";
import { ProductServices } from "./product.services";
import { JwtPayload } from "jsonwebtoken";

const createDataIntoDB = catchAsync(async (req, res) => {
  const result = await ProductServices.createDataIntoDB(req);

  sendResponse(res, {
    statusCode: status.OK,
    message: "Product is created successfully",
    data: result,
  });
});

const getAllDataFromDB = catchAsync(async (req, res) => {
  const filters = pick(req.query, productFilterAbleField);
  const options = pick(req.query, paginationFilterableField);
  const result = await ProductServices.getAllDataFromDB(filters, options);

  sendResponse(res, {
    statusCode: status.OK,
    message: "Product are retrieved successfully",
    meta: result.meta,
    data: result.data,
  });
});
const getAllMyDataFromDB = catchAsync(async (req, res) => {
  const user = req.user;
  const filters = pick(req.query, productFilterAbleField);
  const options = pick(req.query, paginationFilterableField);
  const result = await ProductServices.getAllMyDataFromDB(filters, options, user as JwtPayload);

  sendResponse(res, {
    statusCode: status.OK,
    message: "Vendor Product are retrieved successfully",
    meta: result.meta,
    data: result.data,
  });
});

const getBySlugFromDB = catchAsync(async (req, res) => {
  const { id } = req.params;
  const result = await ProductServices.getBySlugFromDB(id);

  sendResponse(res, {
    statusCode: status.OK,
    message: "Product is retrieved successfully",
    data: result,
  });
});
const getByIdFromDB = catchAsync(async (req, res) => {
  const { id } = req.params;
  const result = await ProductServices.getByIdFromDB(id);

  sendResponse(res, {
    statusCode: status.OK,
    message: "Product is retrieved successfully",
    data: result,
  });
});
const getByIdsFromDB = catchAsync(async (req, res) => {

  const result = await ProductServices.getByIdsFromDB(req);

  sendResponse(res, {
    statusCode: status.OK,
    message: "Product are retrieved successfully",
    data: result,
  });
});

const updateByIdIntoDB = catchAsync(async (req, res) => {
  const { id } = req.params;
  const result = await ProductServices.updateByIdIntoDB(id, req);

  sendResponse(res, {
    statusCode: status.OK,
    message: "Product is updated successfully",
    data: result,
  });
});
const softDeleteByIdFromDB = catchAsync(async (req, res) => {
  const { id } = req.params;
  const result = await ProductServices.softDeleteByIdFromDB(id);

  sendResponse(res, {
    statusCode: status.OK,
    message: "Product Status Changed successfully",
    data: result,
  });
});


const relatedProducts = catchAsync(async (req, res) => {
  const { id } = req.params;
  const result = await ProductServices.relatedProducts(id);

  sendResponse(res, {
    statusCode: status.OK,
    message: "Related Products are retrieved successfully",
    data: result,
  });
});

export const ProductControllers = {
  createDataIntoDB,
  getAllDataFromDB,
  getBySlugFromDB,
  getByIdFromDB,
  updateByIdIntoDB,
  softDeleteByIdFromDB,
 
  relatedProducts,
  getByIdsFromDB,
  getAllMyDataFromDB
};
