export type IProductFilterFields = {
  name?: string | undefined;
  searchTerm?: string | undefined;
};
